import NavDots from './components/NavDots'
import Header from './components/Header'
import SectionWrapper from './components/SectionWrapper'

import Landing from './sections/Landing'
import Intro from './sections/Intro'
import Education from './sections/Education'
import Experience from './sections/Experience'
import Projects from './sections/Projects'
import Events from './sections/Events'
import Footer from './components/Footer'

const sectionsMeta = [
  { id: 'home', label: 'Home' },
  { id: 'intro', label: 'About' },
  { id: 'education', label: 'Education' },
  { id: 'experience', label: 'Experience' },
  { id: 'projects', label: 'Projects' },
  { id: 'events', label: 'Events' }
]

const sectionComponents = {
  home: Landing,
  intro: Intro,
  education: Education,
  experience: Experience,
  projects: Projects,
  events: Events
}

export default function Home() {
  return (
    <>
      <Header />
      <NavDots sections={sectionsMeta} />
      <main id="sections" aria-label="Full page sections">
        {sectionsMeta.map((s, idx) => {
          const Comp = sectionComponents[s.id]
          return (
            <SectionWrapper key={s.id} id={s.id} index={idx}>
              <Comp />
            </SectionWrapper>
          )
        })}
      </main>
      <Footer />
    </>
  )
}
