module.exports = {
  plugins: {
    // use the separate PostCSS plugin package required by Tailwind v4+
    '@tailwindcss/postcss': {},
    autoprefixer: {}
  }
}
